from django.urls import path
from . import views
from sample.members import views
urlpatterns = [

path('home/',views.home,name="home"),
path('main/',views.main,name="main"),
path('index/',views.index,name="index"),
path('dept/',views.dept,name="dept"),
path('loop/',views.loop,name="loop"),
path('sample/',views.sample,name="sample"),
path('cars/',views.cars,name="cars"),
path('data/',views.data,name="data"),
]