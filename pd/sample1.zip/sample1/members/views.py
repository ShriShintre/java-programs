from django.http import HttpResponse
from django.shortcuts import render

def home(request):
        return render(request,'first.html')
def index(request):
        context = {
    'firstname': 'ABC',
    'frontend' : 'Bootstrap',
    'backend'  : 'Mysql and Sqlite',
    'frame':'Django'
  }
        return render(request,'index.html',context)
def main(request):
        return render(request,'aboutus.html')

def dept(request):
        return render(request,'mcadept.html')
def loop(request):
        context = {
     'fruits': ['Apple', 'Banana', 'Cherry'],   
      }
        return render(request,'loop.html',context)
def sample(request):
        context={
        "name":"students"     
        }
        return render(request,'sample.html',context)
def cars(request):
     context = {
    'cars': [
      {
        'brand': 'Ford',
        'model': 'Mustang',
        'year': '1964',
      },
      {
        'brand': 'Ford',
        'model': 'Bronco',
        'year': '1970',
      },
      {
        'brand': 'Volvo',
        'model': 'P1800',
        'year': '1964',
      }]
    }
     return render(request, "cars.html", context)
def data(request):
    # create a dictionary
    context = {
        "test" : [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    }
    # return response
    return render(request, "data.html", context)

